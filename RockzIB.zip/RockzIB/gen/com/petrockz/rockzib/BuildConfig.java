/** Automatically generated file. DO NOT MODIFY */
package com.petrockz.rockzib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
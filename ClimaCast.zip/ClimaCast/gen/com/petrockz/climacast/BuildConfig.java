/** Automatically generated file. DO NOT MODIFY */
package com.petrockz.climacast;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}